"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Product = (function () {
    function Product(name, stockLasts, price, quantity, rating, ImageUrl, likes) {
        this.name = name;
        this.stockLasts = stockLasts;
        this.price = price;
        this.quantity = quantity;
        this.rating = rating;
        this.ImageUrl = ImageUrl;
        this.likes = likes;
    }
    return Product;
}());
exports.default = Product;
//# sourceMappingURL=product.model.js.map