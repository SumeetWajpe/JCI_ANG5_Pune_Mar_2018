import {Component,Input, OnInit} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
    selector:`post-details`,
    template:`<h1> Post Details for {{postId}} </h1>
  
    `
})
export class PostDetailsComponent implements OnInit{


public postId:number;

    constructor(private currRoute:ActivatedRoute){

    }
     ngOnInit(){
            this.currRoute.params.subscribe(
                (p)=>this.postId = p['id']
            )
     }
 
}