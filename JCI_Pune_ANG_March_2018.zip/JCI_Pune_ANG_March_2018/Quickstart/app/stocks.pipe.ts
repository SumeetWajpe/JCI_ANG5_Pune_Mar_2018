import {Pipe,PipeTransform} from '@angular/core'


@Pipe({
    name:'stockduration'
})
export class StockPipe implements PipeTransform{

    transform(theInput:number,theArgs:string){
        return theInput + " " + theArgs ;
    }
}