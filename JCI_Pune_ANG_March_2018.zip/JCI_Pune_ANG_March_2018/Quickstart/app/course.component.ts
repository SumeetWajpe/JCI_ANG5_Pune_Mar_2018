import {Component,Input, ViewChild, ElementRef} from '@angular/core';

@Component({
    selector:`course`,
    template:`

  <input type="text" #myInputText />

  <input type="button" value="Send !" (click)="sendToServer()" />

    `
})
export class CourseComponent{
  

  @ViewChild('myInputText') inputName:ElementRef;

  sendToServer(){
    let data = this.inputName.nativeElement.value;
    console.log(data);
  }
}