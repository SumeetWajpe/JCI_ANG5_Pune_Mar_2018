import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-of-courses',
  templateUrl: './list-of-courses.component.html',
  styleUrls: ['./list-of-courses.component.css']
})
export class ListOfCoursesComponent implements OnInit {

  courses:Array<{name:string}> = [];
  course:string="";
  constructor() {

   }

   ngOnInit() {
  }

   addCourse(){
      this.courses.push({name:this.course});
   }

   onCourseDelete(theIndex:number){
      // Delete logic

      this.courses.splice(theIndex,1);
   }

   ChangeCourse(){
     this.courses[0].name = "HardCodedValue";
   }

  

}
