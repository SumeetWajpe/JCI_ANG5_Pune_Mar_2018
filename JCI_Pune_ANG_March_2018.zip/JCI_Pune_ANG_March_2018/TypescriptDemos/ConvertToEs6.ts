let someVar:number=10000;

function Add(x:any,y:any){
    return x + y;
}