
import {Component,Input} from '@angular/core'


@Component({
selector:`product`,
template:`
<!-- <div [style.backgroundColor]="shouldBeApplied ? 'green' : 'red' ">-->

<!-- <div class="ProductStyle" [class.Highlight]="shouldBeApplied" > -->

<!-- <div [ngClass]="classToBeApplied"> -->
<!-- <div [ngClass]="{'ProductStyle':true,'Highlight':shouldBeApplied}"> -->
<!--<div [ngClass]="['ProductStyle','Highlight']">-->

<div productStyle productColor="lightgreen">
<input type="checkbox" [(ngModel)]="shouldBeApplied" />
<h2> {{prodDetails.name | uppercase }} </h2>

<likes [noOfLikes] ="prodDetails.likes" (changeLikes)="ParentChangeLikesHandler($event)"></likes>
<br/>

<img [src]="prodDetails.ImageUrl" height="200px" width="200px"  /> <br/>
               
<p *ngIf="!isFree">
<b> Price :  </b> {{prodDetails.price | currency:'INR':true }} 
</p>
                <b> Quantity :  </b> {{prodDetails.quantity}} <br/>
                <b> Stock Lasts :  </b> {{prodDetails.stockLasts | stockduration:'hours' }} <br/>
                
                <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2' }} <br/>  
                RAW Data : {{ prodDetails | json }}              
    </div> 
`,
styles:[`.ProductStyle{
    border: 2px solid red;
    border-radius: 20px;
    padding:20px;    
    margin:10px;
  }
  .Highlight{    background-color: lightblue;  }
`]})
export class ProductComponent{
     @Input()   prodDetails={};
     isFree:boolean=false;
     shouldBeApplied:boolean=false;
     classToBeApplied:string="ProductStyle";

     ParentChangeLikesHandler($event:any){
       console.log('Within Parent !');
        console.log($event);
     }
}