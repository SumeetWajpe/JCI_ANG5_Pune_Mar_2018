import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {RouterModule,Routes} from '@angular/router';

import { AppComponent }  from './app.component';
import { CourseComponent } from './course.component';
import  ShoppingCartComponent,{PI}  from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { StockPipe } from './stocks.pipe';
import { UseCourseServiceComponent } from './usecourseservice.component';
import { CourseService } from './courses.service';
import { PostsComponent } from './posts.component';
import { PostDetailsComponent } from './postdetails.component';
import { LoginComponent } from './login.component';
import { DashboardComponent } from './dashboard.component';
import { UserService } from './user.service';
import { AuthGaurd } from './authgaurd.gaurd';
import { ProductDirective } from './productstyle.directive';
import { LikesComponent } from './likes.component';

//{path:'cart',component:ShoppingCartComponent},
// {path:'posts',component:PostsComponent},

const routes:Routes = [

{path:'post/:id',component:PostDetailsComponent},
{
  path:'dashboard',
  //canActivate:[AuthGaurd],
  component:DashboardComponent  ,
  children:[
    {path:'',component:PostsComponent},
    {path:'cart',component:ShoppingCartComponent}    
  ]
},
{path:'',component:LoginComponent},
{path:'**',redirectTo:'/posts',pathMatch:'full'}
];


@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,ProductDirective, LikesComponent , LoginComponent, DashboardComponent, PostsComponent, PostDetailsComponent, UseCourseServiceComponent,StockPipe ,CourseComponent,ProductComponent,ShoppingCartComponent ],
  bootstrap:    [ AppComponent ],
  providers:[CourseService,UserService,AuthGaurd]
})
export class AppModule { }
