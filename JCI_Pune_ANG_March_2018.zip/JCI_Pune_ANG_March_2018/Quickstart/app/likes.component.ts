import {Component,Input,EventEmitter,Output} from '@angular/core';


@Component({
    selector:`likes`,
    template:`


    
   Likes :  {{count}}  &nbsp;&nbsp;



   <button class="btn btn-primary btn-sm" (click)="IncrementLikes()"><span class="glyphicon glyphicon-thumbs-up"></span></button>   &nbsp;&nbsp;  &nbsp;&nbsp;
   <button class="btn btn-primary btn-sm" (click)="DecrementLikes()"><span class="glyphicon glyphicon-thumbs-down"></span></button>

    `
})
export class LikesComponent{
   @Input('noOfLikes')  
    count:number=0;

    @Output() changeLikes:EventEmitter<number> = new EventEmitter<number>();


    IncrementLikes(){
        this.count += 1;
        this.changeLikes.emit(this.count); // emit ! / publish
    }

    DecrementLikes(){
        this.count -= 1;        
    }
}