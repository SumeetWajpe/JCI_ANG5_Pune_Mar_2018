
import {Component} from '@angular/core';
import Product from './product.model';
import {ProductService} from './product.service';
@Component({
selector:`shoppingcart`,
templateUrl:'./app/shoppingcart.template.html',
providers:[ProductService],
styles:[
    `
    input.ng-pristine.ng-invalid{
        background-color:lightblue;
    }

    input.ng-dirty.ng-invalid{
        border:2px solid red;
    }
    
    input.ng-dirty.ng-valid{
        background-color:lightgreen;
    }
    
    
    `
]
})
export default class ShoppingCartComponent{
       heading:string="Shopping Cart";
       companyName:string="";
       productToBeSearched:string="";
       newProduct:Product  =new Product();;
    products:Product[] = [];

    constructor(private prodServObj:ProductService){
        this.products = this.prodServObj.getAllProducts();
       
        //for persitent storage !
        // localStorage["products"] = JSON.stringify(this.products);

    }


        ChangeHeading(){
            this.heading = "Flipkart !";
        }

        ChangeHeadingOnInput(e:any){
           this.heading = e.target.value; // textbox & value
        }

        HandleFormSubmit(thePassedForm:any){
            // add the new Product Here !

            var NewProductToBeAdded:Product = new Product(
                this.newProduct.name,
                2,30000,
                this.newProduct.quantity,
                this.newProduct.rating,
                  "https://paramountseeds.com/wp-content/uploads/2014/07/no_image1.gif"       
            )

            this.products.push(NewProductToBeAdded);
            this.newProduct = new Product();
            thePassedForm.reset();
        }
      
}


export const PI = 31.4;
