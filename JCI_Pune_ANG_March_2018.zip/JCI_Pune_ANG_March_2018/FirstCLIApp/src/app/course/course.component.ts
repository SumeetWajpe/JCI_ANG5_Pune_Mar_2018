import { Component, OnInit,Input, Output,EventEmitter, OnChanges, SimpleChanges, AfterContentChecked, AfterContentInit, OnDestroy } from '@angular/core';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit,OnChanges,AfterContentInit,AfterContentChecked,OnDestroy {

  constructor() { 
    console.log(`Course constructor: name -> ${this.inputcourse} , index -> ${this.courseindex}`)
  }

  // gets called after constructor & used to initialize component !
  ngOnInit() {
    console.log(`Course ngOnInit : name -> ${this.inputcourse} , index -> ${this.courseindex}`)
  }

  // called on change of any input property !
  ngOnChanges(theChanges:SimpleChanges){
      console.log('Course ngOnChanges');

      for(let prop in theChanges){
      console.log(`Property Name :  ${prop} , Current Value : ${theChanges[prop].currentValue} , Previous Value : ${theChanges[prop].previousValue}`)
          
      } 
  }

  ngAfterContentInit(){
        console.log('ngAfterContentInit called !');
  }
  ngAfterContentChecked(){
    console.log('ngAfterContentChecked called !');    
  }

  ngAfterViewInit(){
    console.log('ngAfterViewInit called !');
}

ngAfterViewChecked(){
console.log('ngAfterViewChecked called !');    
}

ngOnDestroy(){
  console.log('Any Clean Up code !');
}
  


  @Input('coursename') inputcourse:string;
  @Input('courseindex') courseindex:number;
  @Output('courseDeleted') courseDeleted:EventEmitter<number> = new EventEmitter<number>();


  

  DeleteCourse(){
      this.courseDeleted.emit(this.courseindex);
  }



}
