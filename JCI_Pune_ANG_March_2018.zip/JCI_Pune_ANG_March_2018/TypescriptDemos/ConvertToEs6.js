let someVar = 10000;
function Add(x, y) {
    return x + y;
}
