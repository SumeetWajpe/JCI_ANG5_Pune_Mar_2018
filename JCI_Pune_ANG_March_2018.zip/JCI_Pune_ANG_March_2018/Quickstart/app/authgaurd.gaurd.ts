import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from "@angular/router";
import { Injectable } from "@angular/core";
import { UserService } from "./user.service";


@Injectable()
export class AuthGaurd implements CanActivate{
    constructor(private user:UserService,private route:Router) {}   

    canActivate(next:ActivatedRouteSnapshot,state:RouterStateSnapshot):boolean{
        
        // redirect to "/" if not authenticated !

        if(!this.user.getUserLoggedIn()){
            this.route.navigate(["/"]);
        }
        return this.user.getUserLoggedIn() ;
        //return true;
    }

}