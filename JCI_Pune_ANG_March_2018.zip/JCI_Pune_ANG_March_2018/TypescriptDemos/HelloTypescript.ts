var msg = "Hello Typescript !";// Type inference
console.log(msg);

var x:number; // Type annotation
var boolVar:boolean;
var strVar:string;

var anyType:any;
anyType = 1000;
anyType = {name:'JCI',location:'Pune'};
anyType = [10,20,30,40];


function Addition(x:number,y:number):number|string{
    if(x<0){
        return 'X should be greater than zero !';
    }
        return  x + y;
}

var result:number|string = Addition(20,30);

 if(true){
     let y = 10000;
     if(true){
         let y = 30000;
     }
 }
// console.log(y); // y not accessible !

const PI = 3.14;

// Arrays
let cars:string[] = ['BMW','AUDI','FERRARI'];
let moreCars:Array<string> = new Array<string>('Hyundai','TATA'); // Using Generics


for(let car of cars){
    console.log(car);
}

// Spread Operator 
let allCars = [...cars,...moreCars,'MAHINDRA'];
console.log(allCars);

// Enumerations
enum Designations{
    Trainer,
    Developer,
    Tester,
    Architect
}

let myDesgn:Designations;
myDesgn = Designations.Trainer;
console.log(myDesgn); //prints numeric value
console.log(Designations[myDesgn]);// prints symbolic value


// GetAllBooks() returns an array of objects
// Every book -> title,price,author,publication
// print all books (for of)

enum Category{
    Action,Autobiography,Inspiration,Fiction   
}

interface IBook{
    title:string,
    author:string,
    price:number,
    publication:string,
    bookCategory:Category
}
function GetAllBooks():IBook[]{
    var allBooks:IBook[]=[
        {title:'Playing It My Way',author:'Sachin Tendulkar',price:800,publication:'Amwy',bookCategory:Category.Autobiography},
        {title:'I am Malala',author:'Malala',price:500,publication:'JKT',bookCategory:Category.Autobiography},
        {title:'Wings Of Fire',author:'Dr. APJ Abdum Kalam',price:400,publication:'Amwy',bookCategory:Category.Inspiration},
        {title:'India 2020',author:'Dr. APJ Abdum Kalam',price:500,publication:'Amwy',bookCategory:Category.Inspiration},
        {title:'Mrtyunjay',author:'Ranjit Desai',price:800,publication:'SKS',bookCategory:Category.Fiction}
        
    ];
    
    return  allBooks;
}
var AllBooks:IBook[] = GetAllBooks();

for(let book of AllBooks){
    console.log(`${book.title} is of Rs.  ${book.price}`);
}

//bookCategory -> Category enum (Action,Autobiography,Inspiration,Fiction)


// GetBooksByCategory(inputCategory) returns an array of strings (title)


function GetBooksByCategory(inputCategory:Category):string[]{  let filteredBooks:string[] = [];

    for(let currBook of AllBooks){

            if(currBook.bookCategory == inputCategory){
                filteredBooks.push(currBook.title);
            }
    }
return filteredBooks;
}

let biographyBooks:string[] = GetBooksByCategory(Category.Autobiography);

// function Square(x:number){
//     return  x * x;
// }

// var Square = function(x:number){
//     return  x * x;
// }

// Arrow function
// var Square = (x:number) => {
//     return  x * x;
// }

var Square = x => x*x;

biographyBooks.forEach(function(theBook,index){
        console.log(theBook);
});

// OR

biographyBooks.forEach((b,i) => console.log(b));

function Emp(){
    this.Salary = 10000;

    setTimeout(()=>{
        console.log(this.Salary)
    },2000)


}
// var emp = new Emp();
// Parameters
//1. Default
//2.Optional
//3. Rest


//Optional
// function PrintBook(author?:string,typeOfPrint?:string){
// //    author = author || "unknown";
// }

// PrintBook();
// PrintBook("Sachin");
// PrintBook("Sachin","Colour");

// Default Parameters:

// function PrintBook(author:string="unknown",typeOfPrint:string="B/W"){
//    console.log(author,typeOfPrint)
//     }
// PrintBook();

// Rest Arguments:

function PrintBook(author:string,...restOfArgs:any[]){
    console.log(author,restOfArgs)
     }

     PrintBook("Sachin","Playing It My Way");
     PrintBook("Ranjit Desai","Mrtyunjay","Chava","Radhey");



     interface ICompany{
         name:string;
         location:string;
         isMNC?:boolean
         getDetails():void;
     }


     var company:ICompany = {name:'JCI',location:'PUNE',getDetails:function(){

     }
    };

    // Classes


   class Car{
    // private   id:number;
       name:string;
       speed:number;
       constructor(theName:string="",theSpeed:number=0){
            this.name = theName;
            this.speed = theSpeed;
       }

       Accelerate():string{
            return (`${this.name} is running at ${this.speed} kmph !`)
       }
   }

//    var carObj = new Car(); // instantiates
//    carObj.Accelerate();
   

 class JamesBondCar extends Car{
        canFly:boolean;
        beInvisible:boolean;
        constructor(theName:string,theSpeed:number,canItFly:boolean,BeInvisible:boolean){
            super(theName,theSpeed);
        }

        Accelerate():string{
                return  super.Accelerate() + " Can It Fly ? " + this.canFly;
        }
 }


 var jbc:JamesBondCar = new JamesBondCar("Houston",300,true,false);
jbc.Accelerate();


interface IPerson{
    name:string;
    age:number;
    
}

interface IEmployee{
    email:string;
    getSalary():number;
}

class Human{

}
 class CPerson extends Human implements IPerson,IEmployee{
    name:string;
    age:number;
    email:string;
    getSalary():number{
        return  1000000;
    }
 }

 var p = new CPerson();

// A shortcut way of creating member variables !



class EnhancedCar{
    constructor(public name:string,public speed:number){

    }   
}

var c = new EnhancedCar("i20",200);


function Swap<T>(x:T,y:T){
        let temp:T;
        temp = x;
        x = y;
        y = temp;
}
Swap<number>(100,200);

class Point<T>{
    x:T;
    y:T;
}


var pt = new Point<string>();





















     








