import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template:`
  <h1> Routing & Navigation </h1>

  <course></course>

  <hr/>

  <!--
  <a routerLink="/posts" class="btn btn-success">Posts</a>
  <a routerLink="/cart" class="btn btn-success">Shopping Cart</a>
  -->

<!--
  <a [routerLink]="['/posts']" class="btn btn-success">Posts</a>
  <a [routerLink]="['/cart']" class="btn btn-success">Shopping Cart</a>
-->
  

  <router-outlet></router-outlet>
  `
  // template:`<post></post>`
  // template:`<shoppingcart></shoppingcart>`
  // template:`<use-course-service></use-course-service>
  // <use-course-service></use-course-service>`
  
  // template: `
  // <div *ngFor="let c of courses">
  //   <course [details]="c"></course>
  // </div>
  // `
})
export class AppComponent  { 
  courses:any[]=[{name:'ReactJS',duration:'3 Days',price:3000},
  {name:'NodeJS',duration:'3 Days',price:4000},
  {name:'KnockoutJS',duration:'2 Days',price:2000}];
}
