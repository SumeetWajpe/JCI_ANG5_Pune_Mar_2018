import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-panel',
  templateUrl: './my-panel.component.html',
  styleUrls: ['./my-panel.component.css']
})
export class MyPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
