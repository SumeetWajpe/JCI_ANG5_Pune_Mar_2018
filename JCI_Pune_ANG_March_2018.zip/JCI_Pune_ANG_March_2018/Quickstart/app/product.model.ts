export default class Product{
   constructor( public name?:string,
    public stockLasts?:number,
    public price?:number,
    public quantity?:number,
    public rating?:number,
    public ImageUrl?:string,
public likes?:number){

    }
      
}