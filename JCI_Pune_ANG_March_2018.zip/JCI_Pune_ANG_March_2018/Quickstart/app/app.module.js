"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var forms_1 = require("@angular/forms");
var http_1 = require("@angular/http");
var router_1 = require("@angular/router");
var app_component_1 = require("./app.component");
var course_component_1 = require("./course.component");
var shoppingcart_component_1 = require("./shoppingcart.component");
var product_component_1 = require("./product.component");
var stocks_pipe_1 = require("./stocks.pipe");
var usecourseservice_component_1 = require("./usecourseservice.component");
var courses_service_1 = require("./courses.service");
var posts_component_1 = require("./posts.component");
var postdetails_component_1 = require("./postdetails.component");
var login_component_1 = require("./login.component");
var dashboard_component_1 = require("./dashboard.component");
var user_service_1 = require("./user.service");
var authgaurd_gaurd_1 = require("./authgaurd.gaurd");
var productstyle_directive_1 = require("./productstyle.directive");
var likes_component_1 = require("./likes.component");
//{path:'cart',component:ShoppingCartComponent},
// {path:'posts',component:PostsComponent},
var routes = [
    { path: 'post/:id', component: postdetails_component_1.PostDetailsComponent },
    {
        path: 'dashboard',
        //canActivate:[AuthGaurd],
        component: dashboard_component_1.DashboardComponent,
        children: [
            { path: '', component: posts_component_1.PostsComponent },
            { path: 'cart', component: shoppingcart_component_1.default }
        ]
    },
    { path: '', component: login_component_1.LoginComponent },
    { path: '**', redirectTo: '/posts', pathMatch: 'full' }
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule, http_1.HttpModule, router_1.RouterModule.forRoot(routes)],
        declarations: [app_component_1.AppComponent, productstyle_directive_1.ProductDirective, likes_component_1.LikesComponent, login_component_1.LoginComponent, dashboard_component_1.DashboardComponent, posts_component_1.PostsComponent, postdetails_component_1.PostDetailsComponent, usecourseservice_component_1.UseCourseServiceComponent, stocks_pipe_1.StockPipe, course_component_1.CourseComponent, product_component_1.ProductComponent, shoppingcart_component_1.default],
        bootstrap: [app_component_1.AppComponent],
        providers: [courses_service_1.CourseService, user_service_1.UserService, authgaurd_gaurd_1.AuthGaurd]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map