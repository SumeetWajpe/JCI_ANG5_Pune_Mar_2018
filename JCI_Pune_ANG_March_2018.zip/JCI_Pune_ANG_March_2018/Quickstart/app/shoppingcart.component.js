"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var product_model_1 = require("./product.model");
var product_service_1 = require("./product.service");
var ShoppingCartComponent = (function () {
    function ShoppingCartComponent(prodServObj) {
        this.prodServObj = prodServObj;
        this.heading = "Shopping Cart";
        this.companyName = "";
        this.productToBeSearched = "";
        this.newProduct = new product_model_1.default();
        this.products = [];
        this.products = this.prodServObj.getAllProducts();
        //for persitent storage !
        // localStorage["products"] = JSON.stringify(this.products);
    }
    ;
    ShoppingCartComponent.prototype.ChangeHeading = function () {
        this.heading = "Flipkart !";
    };
    ShoppingCartComponent.prototype.ChangeHeadingOnInput = function (e) {
        this.heading = e.target.value; // textbox & value
    };
    ShoppingCartComponent.prototype.HandleFormSubmit = function (thePassedForm) {
        // add the new Product Here !
        var NewProductToBeAdded = new product_model_1.default(this.newProduct.name, 2, 30000, this.newProduct.quantity, this.newProduct.rating, "https://paramountseeds.com/wp-content/uploads/2014/07/no_image1.gif");
        this.products.push(NewProductToBeAdded);
        this.newProduct = new product_model_1.default();
        thePassedForm.reset();
    };
    return ShoppingCartComponent;
}());
ShoppingCartComponent = __decorate([
    core_1.Component({
        selector: "shoppingcart",
        templateUrl: './app/shoppingcart.template.html',
        providers: [product_service_1.ProductService],
        styles: [
            "\n    input.ng-pristine.ng-invalid{\n        background-color:lightblue;\n    }\n\n    input.ng-dirty.ng-invalid{\n        border:2px solid red;\n    }\n    \n    input.ng-dirty.ng-valid{\n        background-color:lightgreen;\n    }\n    \n    \n    "
        ]
    }),
    __metadata("design:paramtypes", [product_service_1.ProductService])
], ShoppingCartComponent);
exports.default = ShoppingCartComponent;
exports.PI = 31.4;
//# sourceMappingURL=shoppingcart.component.js.map