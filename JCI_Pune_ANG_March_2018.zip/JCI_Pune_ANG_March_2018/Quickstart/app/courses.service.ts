export class CourseService{
    private listOfCourses:string[] = ["ReactJS","NodeJS","Angular"]


    getAllCourses():string[]{
        return this.listOfCourses;
    }
    insertNewCourse(newCourse:string):void{
        this.listOfCourses.push(newCourse);
    }

    getRandomCourse():string{
            return  this.listOfCourses[Math.floor(Math.random() * this.listOfCourses.length)];
    }
}