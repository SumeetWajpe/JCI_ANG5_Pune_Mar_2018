import {Component,Input} from '@angular/core';
import {CourseService} from './courses.service';

@Component({
    selector:`use-course-service`,
    template:`
    <div style="width:500px;border:2px solid red;border-radius:10px;padding:20px;margin:20px;">
    <h1> List Of Courses </h1>
    New Course : <input type="text" class="form-control" [(ngModel)]="courseToBeAdded" /> {{courseReceived}} <br/>
    <input type="button" (click)="AddCourse()" value="Add Course >>" class="btn btn-primary" />
    <input type="button" (click)="GetCourse()" value="Get Random Course" class="btn btn-primary" />    
    </div>`
    // ,  
    //   providers:[CourseService]
     })
export class UseCourseServiceComponent{
    courseToBeAdded:string="";
    courseReceived:string="";
    // Dep Injection happens here !
    constructor(private servObj:CourseService){   }
    AddCourse():void{            this.servObj.insertNewCourse(this.courseToBeAdded);
    }
    GetCourse():void{
        this.courseReceived =    this.servObj.getRandomCourse();
    }
  
}