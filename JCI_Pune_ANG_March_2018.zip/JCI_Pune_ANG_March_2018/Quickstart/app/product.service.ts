import Product from './product.model';

export class ProductService{
    private products:Product[] = [
        new Product('Laptop',2,40000,30,3,'https://rukminim1.flixcart.com/image/704/704/j431rbk0/computer/t/h/p/hp-notebook-original-imaev2zfjqfpf3ng.jpeg?q=70',20),
        new Product('LED TV',3,50000,30,3,'http://www.lg.com/in/images/tvs/md05602497/gallery/Large-940x620.jpg',10),
        new Product('Desktop',2,20000,30,3,'https://images-eu.ssl-images-amazon.com/images/I/41IjXCFmiRL._SL500_AC_SS350_.jpg',40),
        new Product('Mobile',2,30000,30,3,'https://assets.mspcdn.net/t_c-desktop-normal,f_auto,q_auto,d_c:noimage.jpg/c/8808-62-4.jpg',60),
        new Product('Camera',2,50000,30,3,'https://cdn-4.nikon-cdn.com/e/Q5NM96RZZo-YRYNeYvAi9beHK4x3L-8joW7yUnybX4TANUFk0STA8w==/Views/1554_D7200_left.png',25)
             ];   
    getAllProducts():Product[]{
        return this.products;
    }
   
}