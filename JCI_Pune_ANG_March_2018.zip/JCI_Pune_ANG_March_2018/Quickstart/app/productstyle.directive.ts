import { Directive, ElementRef, Input,HostListener } from "@angular/core";

@Directive({
    selector:'[productStyle]'
})
export class ProductDirective{

 @Input('productColor')   passedColor:string="Yellow";

constructor(private refElement:ElementRef){

}

ngOnInit(){
    this.refElement.nativeElement.style.backgroundColor = this.passedColor;
    this.refElement.nativeElement.style.border = "2px solid red";
    this.refElement.nativeElement.style.borderRadius = "10px";
    
    this.refElement.nativeElement.style.margin = "10px";
    this.refElement.nativeElement.style.padding = "10px"; 
}
@HostListener('mouseenter') on_mouse_enter(){
this.refElement.nativeElement.style.backgroundColor= "orange";
}
@HostListener('mouseleave') on_mouse_leave(){
    this.refElement.nativeElement.style.backgroundColor= this.passedColor;
}

}