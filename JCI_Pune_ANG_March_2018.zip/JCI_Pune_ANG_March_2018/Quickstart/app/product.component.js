"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var ProductComponent = (function () {
    function ProductComponent() {
        this.prodDetails = {};
        this.isFree = false;
        this.shouldBeApplied = false;
        this.classToBeApplied = "ProductStyle";
    }
    ProductComponent.prototype.ParentChangeLikesHandler = function ($event) {
        console.log('Within Parent !');
        console.log($event);
    };
    return ProductComponent;
}());
__decorate([
    core_1.Input(),
    __metadata("design:type", Object)
], ProductComponent.prototype, "prodDetails", void 0);
ProductComponent = __decorate([
    core_1.Component({
        selector: "product",
        template: "\n<!-- <div [style.backgroundColor]=\"shouldBeApplied ? 'green' : 'red' \">-->\n\n<!-- <div class=\"ProductStyle\" [class.Highlight]=\"shouldBeApplied\" > -->\n\n<!-- <div [ngClass]=\"classToBeApplied\"> -->\n<!-- <div [ngClass]=\"{'ProductStyle':true,'Highlight':shouldBeApplied}\"> -->\n<!--<div [ngClass]=\"['ProductStyle','Highlight']\">-->\n\n<div productStyle productColor=\"lightgreen\">\n<input type=\"checkbox\" [(ngModel)]=\"shouldBeApplied\" />\n<h2> {{prodDetails.name | uppercase }} </h2>\n\n<likes [noOfLikes] =\"prodDetails.likes\" (changeLikes)=\"ParentChangeLikesHandler($event)\"></likes>\n<br/>\n\n<img [src]=\"prodDetails.ImageUrl\" height=\"200px\" width=\"200px\"  /> <br/>\n               \n<p *ngIf=\"!isFree\">\n<b> Price :  </b> {{prodDetails.price | currency:'INR':true }} \n</p>\n                <b> Quantity :  </b> {{prodDetails.quantity}} <br/>\n                <b> Stock Lasts :  </b> {{prodDetails.stockLasts | stockduration:'hours' }} <br/>\n                \n                <b> Rating :  </b> {{prodDetails.rating | number:'1.1-2' }} <br/>  \n                RAW Data : {{ prodDetails | json }}              \n    </div> \n",
        styles: [".ProductStyle{\n    border: 2px solid red;\n    border-radius: 20px;\n    padding:20px;    \n    margin:10px;\n  }\n  .Highlight{    background-color: lightblue;  }\n"]
    })
], ProductComponent);
exports.ProductComponent = ProductComponent;
//# sourceMappingURL=product.component.js.map