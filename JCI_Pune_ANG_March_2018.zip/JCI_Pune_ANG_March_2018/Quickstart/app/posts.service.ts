import {Http} from '@angular/http';
import {Injectable} from '@angular/core';
import 'rxjs/add/operator/toPromise';

@Injectable()
export class PostsService{
    constructor(private httpObj:Http){ }
    // Using CallBack !
    // getPosts(callbackFunc:any){
    //     // make ajaxfied request here !
    //     this.httpObj.get('https://jsonplaceholder.typicode.com/posts').subscribe(function(response){
    //         callbackFunc(response.json());
    //     })
    // }


    getPosts(){
        // make ajaxfied request here !
      return  this.httpObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();

        // RXJS
    }

}