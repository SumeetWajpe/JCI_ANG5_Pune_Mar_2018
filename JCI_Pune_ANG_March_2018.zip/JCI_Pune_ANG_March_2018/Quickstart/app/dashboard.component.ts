import {Component,Input} from '@angular/core';
import { UserService } from './user.service';

@Component({
    selector:`dashboard`,
    template:`
    <h1> Welcome {{uName}} !! </h1>

   
    <h2> You are authenticated ! </h2>

    <router-outlet></router-outlet>
    `
})
export class DashboardComponent{
  
    uName:string="";
    constructor(private user:UserService){
            this.uName = this.user.username;
    }

}