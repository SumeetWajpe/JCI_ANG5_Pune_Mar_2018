var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var msg = "Hello Typescript !"; // Type inference
console.log(msg);
var x; // Type annotation
var boolVar;
var strVar;
var anyType;
anyType = 1000;
anyType = { name: 'JCI', location: 'Pune' };
anyType = [10, 20, 30, 40];
function Addition(x, y) {
    if (x < 0) {
        return 'X should be greater than zero !';
    }
    return x + y;
}
var result = Addition(20, 30);
if (true) {
    var y = 10000;
    if (true) {
        var y_1 = 30000;
    }
}
// console.log(y); // y not accessible !
var PI = 3.14;
// Arrays
var cars = ['BMW', 'AUDI', 'FERRARI'];
var moreCars = new Array('Hyundai', 'TATA'); // Using Generics
for (var _i = 0, cars_1 = cars; _i < cars_1.length; _i++) {
    var car = cars_1[_i];
    console.log(car);
}
// Spread Operator 
var allCars = cars.concat(moreCars, ['MAHINDRA']);
console.log(allCars);
// Enumerations
var Designations;
(function (Designations) {
    Designations[Designations["Trainer"] = 0] = "Trainer";
    Designations[Designations["Developer"] = 1] = "Developer";
    Designations[Designations["Tester"] = 2] = "Tester";
    Designations[Designations["Architect"] = 3] = "Architect";
})(Designations || (Designations = {}));
var myDesgn;
myDesgn = Designations.Trainer;
console.log(myDesgn); //prints numeric value
console.log(Designations[myDesgn]); // prints symbolic value
// GetAllBooks() returns an array of objects
// Every book -> title,price,author,publication
// print all books (for of)
var Category;
(function (Category) {
    Category[Category["Action"] = 0] = "Action";
    Category[Category["Autobiography"] = 1] = "Autobiography";
    Category[Category["Inspiration"] = 2] = "Inspiration";
    Category[Category["Fiction"] = 3] = "Fiction";
})(Category || (Category = {}));
function GetAllBooks() {
    var allBooks = [
        { title: 'Playing It My Way', author: 'Sachin Tendulkar', price: 800, publication: 'Amwy', bookCategory: Category.Autobiography },
        { title: 'I am Malala', author: 'Malala', price: 500, publication: 'JKT', bookCategory: Category.Autobiography },
        { title: 'Wings Of Fire', author: 'Dr. APJ Abdum Kalam', price: 400, publication: 'Amwy', bookCategory: Category.Inspiration },
        { title: 'India 2020', author: 'Dr. APJ Abdum Kalam', price: 500, publication: 'Amwy', bookCategory: Category.Inspiration },
        { title: 'Mrtyunjay', author: 'Ranjit Desai', price: 800, publication: 'SKS', bookCategory: Category.Fiction }
    ];
    return allBooks;
}
var AllBooks = GetAllBooks();
for (var _a = 0, AllBooks_1 = AllBooks; _a < AllBooks_1.length; _a++) {
    var book = AllBooks_1[_a];
    console.log(book.title + " is of Rs.  " + book.price);
}
//bookCategory -> Category enum (Action,Autobiography,Inspiration,Fiction)
// GetBooksByCategory(inputCategory) returns an array of strings (title)
function GetBooksByCategory(inputCategory) {
    var filteredBooks = [];
    for (var _i = 0, AllBooks_2 = AllBooks; _i < AllBooks_2.length; _i++) {
        var currBook = AllBooks_2[_i];
        if (currBook.bookCategory == inputCategory) {
            filteredBooks.push(currBook.title);
        }
    }
    return filteredBooks;
}
var biographyBooks = GetBooksByCategory(Category.Autobiography);
// function Square(x:number){
//     return  x * x;
// }
// var Square = function(x:number){
//     return  x * x;
// }
// Arrow function
// var Square = (x:number) => {
//     return  x * x;
// }
var Square = function (x) { return x * x; };
biographyBooks.forEach(function (theBook, index) {
    console.log(theBook);
});
// OR
biographyBooks.forEach(function (b, i) { return console.log(b); });
function Emp() {
    var _this = this;
    this.Salary = 10000;
    setTimeout(function () {
        console.log(_this.Salary);
    }, 2000);
}
// var emp = new Emp();
// Parameters
//1. Default
//2.Optional
//3. Rest
//Optional
// function PrintBook(author?:string,typeOfPrint?:string){
// //    author = author || "unknown";
// }
// PrintBook();
// PrintBook("Sachin");
// PrintBook("Sachin","Colour");
// Default Parameters:
// function PrintBook(author:string="unknown",typeOfPrint:string="B/W"){
//    console.log(author,typeOfPrint)
//     }
// PrintBook();
// Rest Arguments:
function PrintBook(author) {
    var restOfArgs = [];
    for (var _i = 1; _i < arguments.length; _i++) {
        restOfArgs[_i - 1] = arguments[_i];
    }
    console.log(author, restOfArgs);
}
PrintBook("Sachin", "Playing It My Way");
PrintBook("Ranjit Desai", "Mrtyunjay", "Chava", "Radhey");
var company = { name: 'JCI', location: 'PUNE', getDetails: function () {
    }
};
// Classes
var Car = /** @class */ (function () {
    function Car(theName, theSpeed) {
        if (theName === void 0) { theName = ""; }
        if (theSpeed === void 0) { theSpeed = 0; }
        this.name = theName;
        this.speed = theSpeed;
    }
    Car.prototype.Accelerate = function () {
        return (this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
//    var carObj = new Car(); // instantiates
//    carObj.Accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(theName, theSpeed, canItFly, BeInvisible) {
        return _super.call(this, theName, theSpeed) || this;
    }
    JamesBondCar.prototype.Accelerate = function () {
        return _super.prototype.Accelerate.call(this) + " Can It Fly ? " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Houston", 300, true, false);
jbc.Accelerate();
var Human = /** @class */ (function () {
    function Human() {
    }
    return Human;
}());
var CPerson = /** @class */ (function (_super) {
    __extends(CPerson, _super);
    function CPerson() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    CPerson.prototype.getSalary = function () {
        return 1000000;
    };
    return CPerson;
}(Human));
var p = new CPerson();
// A shortcut way of creating member variables !
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(name, speed) {
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());
var c = new EnhancedCar("i20", 200);
function Swap(x, y) {
    var temp;
    temp = x;
    x = y;
    y = temp;
}
Swap(100, 200);
var Point = /** @class */ (function () {
    function Point() {
    }
    return Point;
}());
var pt = new Point();
