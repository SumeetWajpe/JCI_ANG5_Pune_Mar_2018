import {Component} from '@angular/core';
import {PostsService} from './posts.service';

@Component({
    selector:`post`,
    template:`
    <h1> Posts </h1>
   <div>
   <ul>
   <li *ngFor="let post of receivedPosts" productStyle>
     <a [routerLink]="['/post',post.id]">       {{ post.title }}  </a>
   </li>
   </ul>
   </div>
    `,
    providers:[PostsService]
})
export class PostsComponent{
    receivedPosts:any[] = [];
  constructor(private postServObj:PostsService){
        // this.postServObj.getPosts((responseFromService:any)=>{
        //       this.receivedPosts = responseFromService;
        // });

     var returnedPromise =   this.postServObj.getPosts(); // returns a promise !
     returnedPromise.then((responseFromService:any)=>{
         this.receivedPosts = responseFromService.json();
     },(error)=>{
            console.log(error);
     }
    )
  }
}