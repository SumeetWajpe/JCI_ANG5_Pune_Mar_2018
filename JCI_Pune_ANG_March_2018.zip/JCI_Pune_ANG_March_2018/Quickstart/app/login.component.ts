import {Component,Input} from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from './user.service';

@Component({
    selector:`login-form`,
    template:`

    <label>Username : </label>
    <form class="form-signin" (ngSubmit)="HandleFormSubmit()">
     
      <div class="form-label-group">
        <input type="text" [(ngModel)]="inputName" name="inputName" class="form-control" placeholder="Username" autofocus="">
        <label for="inputName">Username : </label>
      </div>

      <div class="form-label-group">
        <input type="password" [(ngModel)]="inputPassword" name="inputPassword" class="form-control" placeholder="Password" required="">
        <label for="inputPassword">Password</label>
      </div>

     
      <button class="btn btn-lg btn-primary" type="submit">Sign in</button>

    </form>
    `
})
export class LoginComponent{
  
    private inputPassword:string="";
    private inputName:string="";

    constructor(private route:Router,private user:UserService){
    }

    HandleFormSubmit(){
            if(this.inputName == "admin" && this.inputPassword == "admin")
            {
                    // do redirection here !  
                    // set isUserLoggedIn -> true
                    this.user.setUserLoggedIn();
                    this.user.username = "admin";
                    this.route.navigate(['/dashboard']);             
            }
    }

}